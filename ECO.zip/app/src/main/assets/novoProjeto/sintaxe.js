const editor = document.getElementById('codigo');
const sugestoes = document.getElementById('auto');


const chaves =
`
""
''
{}
()
[]
function
if
else
try
catch
for
forEach
fetch
while
return
const
let
var
class
new
extends
console.log();
console.error();
setTimeout();
setInterval();
addEventListener
document.getElementById
document.createElement
document
document.body
appendChild()
removeChild()
document.querySelector()

engine
add(sprite/particula);
add(sprite/particula, engine.camada);

rm(sprite);
rm(sprite, engine.camada);

novoSprite("caminho/sprite.png");
novoSprite("caminho/sprite.png", engine.camada);

novoBotao("caminho/sprite.png", "click", () => {/* codigo */});
novoBotao("caminho/sprite.png", "loop", () => {/* codigo */});

addBotao(sprite, "click", () => {/* codigo */});
addBotao(sprite, "loop", () => {/* codigo */}, engine.camada);

novoMapa(jsonMapa, listaTiles);
novoMapa(jsonMapa, listaTiles, 0, 0);
novoMapa(jsonMapa, listaTiles, 0, 0, 32);
novoMapa(jsonMapa, listaTiles, 0, 0, 32, engine.camada);

novoTexto();
novoTexto("texto");
novoTexto("texto", "100px");
novoTexto("texto", "100px");
novoTexto("texto", "100px", "blue");
novoTexto("texto", "100px", "blue", engine.camada);

novaCamada();

solidos(sprite1, sprite2);

ajustarTela();
ajustarTela("100px");
ajustarTela("100px", "100px");

rodarAnimacao();
moverPara();
moverParaArray();

repetirAte();
repetirVezes();
esperar();
sempreExecutar();
limpar();
mudarTela();

tamanhoPadrao
renderizacao
camada

ecoEditor
coord
seMove
elemento

Sprite
Sprite("caminho/sprite.png");
Sprite("caminho/sprite.png", 0, 0);
Sprite("caminho/sprite.png", 0, 0, 32, 32);

Particula
Particula("blue");
Particula("null", "caminho/sprite.png");
Particula("null", "caminho/sprite.png", 0, 0);
Particula("null", "caminho/sprite.png", 0, 0, 32, 32);

ArrastavelHtml
ArrastavelHtml("id");
ArrastavelHtml("id", 16);
ArrastavelHtml("id", 16, false);

Camera
Camera(engine, sprite);
Camera(engine, sprite, engine.camada);
ajustar();

Gravidade
Gravidade(sprite);
Gravidade(sprite, 5);
Gravidade(sprite, 5, false);
iniciar();

Android.msg("texto");
Android.arquivar("caminho/arquivo.txt", "conteúdo");
Android.ler("caminho/arquivo.txt");
`
const todasSugestoes = chaves.split("\n");

function exibirSugestoes() {
    const posicaoCursor = editor.selectionStart;
    const textoAntes = editor.value.substring(0, posicaoCursor);
    const linhaAtual = textoAntes.split("\n").pop();
    const palavraAtual = linhaAtual.split(/[\s.,;(){}[\]=+-]/).pop();

    if(!palavraAtual) {
        sugestoes.style.display = "none";
        return;
    }
    
    const sugestoesFiltradas = todasSugestoes.filter(item => item.toLowerCase().includes(palavraAtual.toLowerCase()));

    if(sugestoesFiltradas.length==0) {
        sugestoes.style.display="none";
        return;
    }

    sugestoes.innerHTML = sugestoesFiltradas.map(item => `<div class="sugestao">${item}</div>`).join("");

    const coordenadasCursor=obterCoordenadasCursor();
    sugestoes.style.left=coordenadasCursor.esquerda+"px";
    sugestoes.style.top="40px";
    sugestoes.style.display="block";

    document.querySelectorAll("#auto .sugestao").forEach(item => {
        item.addEventListener("click", ()=> {
            addSugestao(item.textContent, palavraAtual.length);
        });
    });
}

function addSugestao(texto, tamanhoSubstituir) {
    const inicio = editor.selectionStart-tamanhoSubstituir;
    const fim = editor.selectionStart;

    editor.value = editor.value.substring(0, inicio)+ 
                   texto+ 
                   editor.value.substring(fim);

    editor.selectionStart = editor.selectionEnd = inicio + texto.length;
    
    sugestoes.style.display="none";
    editor.focus();
}

function obterCoordenadasCursor() {
    const posicaoCursor = editor.selectionStart;
    const divTemporaria = document.createElement("div");
    divTemporaria.textContent = editor.value.substring(0, posicaoCursor);
    
    divTemporaria.style.whiteSpace = "pre-wrap";
    divTemporaria.style.font=getComputedStyle(editor).font;
    divTemporaria.style.width=editor.clientWidth+"px";
    divTemporaria.style.padding=getComputedStyle(editor).padding;
    divTemporaria.style.position="absolute";
    divTemporaria.style.visibility="hidden";
    document.body.appendChild(divTemporaria);

    const retangulo = divTemporaria.getBoundingClientRect();
    const retanguloEditor = editor.getBoundingClientRect();

    document.body.removeChild(divTemporaria);

    return {
        esquerda: retangulo.left-retanguloEditor.left+editor.scrollLeft,
        topo: retangulo.top-retanguloEditor.top+editor.scrollTop
    };
}

editor.addEventListener('input', exibirSugestoes);

editor.addEventListener("keydown", (evento)=> {
    if(evento.key=="Tab") {
        evento.preventDefault();
        document.execCommand('insertText', false, "\t");
    }
});

document.addEventListener("click", (evento)=> {
    if(evento.target != editor && !sugestoes.contains(evento.target)) {
        sugestoes.style.display = "none";
    }
});
